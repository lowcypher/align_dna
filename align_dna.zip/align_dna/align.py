###############################################
#
# Arquivo: align.py
# Autor: Mario Medeiros
# Versão: 0.1
# Data: 2023-02-18
#
# Dependências:
# biopython
# csv
#
# Finalidade: alinhar sequências DNA em arquivos formato FASTA
# Pode-se utilizar a sequência como varíavel no lugar dos arquivos
# Os testes foram feitos somente com duas sequências pequenas
#
# Este script serve para fins didáticos e para demonstração
# Foi utilizado exemplos de outros códigos da documentação
# do desenvolvedor da biblioteca BioPython
# Utilizada a versão 1.81
# Obs: a partir da versão 1.76 o mṕdulo pairwise2 foi
# substituída pela PairwiseAligner
#
# Este script foi desenvolvido com base na PairwiseAligner
# da versão 1.81 da biblioteca BioPython.
#
# Mais informações nos site do desenvolvedor
# Referências e fontes no final do arquivo.
#
###############################################

# importando as bibliotecas necessárias
import csv
from Bio.Seq import Seq
from Bio.Align import PairwiseAligner
from Bio import SeqIO

# define as sequências a serem comparadas
# utilizando arquivos formato fasta
seq1 = str(SeqIO.read("01.fasta", "fasta").seq)
seq2 = str(SeqIO.read("02.fasta", "fasta").seq)

# define as sequências a serem comparadas
# utilizando as seuências diretamente no código
#seq1 = Seq("ATGCTTTTGAGTAAGGAGATATTGCCCTCATTAATAGCATCGTCTGCATTAACAAA")
#seq2 = Seq("ATTCATGCCGGTGCGCAGGTCAAATGCATGAATGCTCCGGGTAGAACGCAGTCTCT")

# define o alinhador
aligner = PairwiseAligner()

# configuração do alinhamento
aligner.mode = 'global'
aligner.match_score = 2
aligner.mismatch_score = -1
aligner.open_gap_score = -2
aligner.extend_gap_score = -1

# realiza o alinhamento
alignments = aligner.align(seq1, seq2)

# imprime o resultado em arquivo TXT
for alignment in alignments:
    print("Score:", alignment.score)
    f = open('alinhamento.txt', 'a')
    print(alignment.score,"\n",alignment, file = f)
    print(alignment)

# salva o resultado em um arquivo CSV
with open('alinhamento.csv', 'w', newline='') as f:
    writer = csv.writer(f, delimiter=';')
    #writer.writerow(['Seq1', 'Seq2', 'Score'])
    writer.writerow(['Query', 'Target', 'Score'])
    for alignment in alignments:
        #writer.writerow([alignment.score, alignment.target, alignment.query])
        #writer.writerow([alignment, alignment, alignment])
        writer.writerow([alignment[0], alignment[1], alignment.score])

########################################
#
# Fontes e Referências:
#
# Documentação e exemplos BioPython:
# https://biopython.org/wiki/Documentation
#
# Informações sobre Salmonella enterica:
# https://www.ncbi.nlm.nih.gov/genome/browse#!/prokaryotes/152/
#
# Arquivos e dados em diversos:
# Salmonella enterica strain SC2014238 plasmid pSC2014238-58k, complete sequence:
# https://www.ncbi.nlm.nih.gov/genome/152?genome_assembly_id=1895943
# https://www.ncbi.nlm.nih.gov/nuccore/2276403672?report=fasta
#
########################################
